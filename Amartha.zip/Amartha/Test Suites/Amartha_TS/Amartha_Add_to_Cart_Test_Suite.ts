<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amartha_Add_to_Cart_Test_Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d4974185-af33-4e33-bac2-7fb08e7ebc67</testSuiteGuid>
   <testCaseLink>
      <guid>b3fb07ff-a22d-4b1c-bf32-312c589e5512</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Add_to_Cart_TC/Add_to_Cart_backpack_from_MainPage</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
