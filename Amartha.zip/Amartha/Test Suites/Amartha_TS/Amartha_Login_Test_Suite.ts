<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Test Suite for Login</description>
   <name>Amartha_Login_Test_Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>2f2d55a7-296d-4f99-a8ff-f7ace5f7b1fa</testSuiteGuid>
   <testCaseLink>
      <guid>6f491322-bde1-4ce2-b532-14ff9cebde87</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_locked_out_user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3fd5b82b-be09-4639-8b8e-728a41ec38a4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_locked_out_user_No_Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>57a01ee3-deff-4378-ad9e-cc2a7859b452</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_performance_glitch_user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cfa061c8-2818-4f5d-b75b-4446ea993ef0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_performance_glitch_user_No_Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ba9523a3-89e8-4f8f-8577-15be2b75b729</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_problem_user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>56c9d191-dd4c-4b76-817a-908f112a8059</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_problem_user_No_Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2ec67da-eda4-41e7-8eb6-ce747883652d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_standard_user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2ddfca1f-549e-4781-8d9d-b8ad13d70e86</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_standard_user_No_Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5841bcdc-e2cc-47e2-b27d-2ed2cb5db7ab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_Wrong_Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>36b65613-b021-4172-a03c-b33a47f13663</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_Login_TC/Login_with_Wrong_User</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
