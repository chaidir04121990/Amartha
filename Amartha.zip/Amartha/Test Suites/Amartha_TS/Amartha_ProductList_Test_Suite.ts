<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amartha_ProductList_Test_Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>e81d1af5-87a5-4867-93fb-9662fb45f780</testSuiteGuid>
   <testCaseLink>
      <guid>f43dc007-c6fd-412f-aff0-76200e87784a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_ProductList_TC/ProductList_Sauce Labs Backpack</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>208fd506-cd6e-4965-b728-fdb385c60136</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>5ae2cd15-5e41-4459-ad0c-cb32046476a8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_ProductList_TC/ProductList_Sauce Labs Bolt T-Shirt</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0ddcf5b5-0e6f-4223-84e5-75a2c575892e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amartha_ProductList_TC/ProductList_Sauce_Labs_Bike_Light</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
