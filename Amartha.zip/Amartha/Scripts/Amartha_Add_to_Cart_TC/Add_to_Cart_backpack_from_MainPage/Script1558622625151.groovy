import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.stringtemplate.v4.compiler.STParser.andConditional_return as andConditional_return
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.saucedemo.com/')

WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/input_standard_userlocked_out_userproblem_userperformance_glitch_user_user-name'), 
    'standard_user')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Swag Labs/input_standard_userlocked_out_userproblem_userperformance_glitch_user_password'), 
    'qcu24s4901FyWDTwXGr6XA==')

WebUI.click(findTestObject('Object Repository/Page_Swag Labs/input_standard_userlocked_out_userproblem_userperformance_glitch_user_btn_action'))

WebUI.navigateToUrl('https://www.saucedemo.com/inventory.html')

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/div_ProductsName (A to Z)Name (Z to A)Price (low to high)Price (high to low)'), 
    30)

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/div_Sauce Labs BackpackcarryallTheThings() with the sleek streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection'), 
    30)

WebUI.click(findTestObject('Object Repository/Page_Swag Labs/button_ADD TO CART'))

WebUI.click(findTestObject('Page_Swag Labs/span_1'))

WebUI.navigateToUrl('https://www.saucedemo.com/cart.html')

WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/div_Sauce Labs Backpack'), 30)

WebUI.click(findTestObject('Object Repository/Page_Swag Labs/a_CHECKOUT'))

WebUI.navigateToUrl('https://www.saucedemo.com/checkout-step-one.html')

WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/div_Checkout Your Information_checkout_info'), 30)

WebUI.setText(findTestObject('Page_Swag Labs/input_Checkout Your Information_first-name'), 'dffs')

WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/input_Checkout Your Information_last-name'), 'sdfds')

WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/input_Checkout Your Information_postal-code'), '123')

WebUI.click(findTestObject('Object Repository/Page_Swag Labs/input_CANCEL_btn_primary cart_button'))

//if (WebUI.getText(findTestObject('Object Repository/Page_Swag Labs/input_Checkout Your Information_first-name', null)).length() < 1 ) {
//    WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/h3_Error First Name is required'), 30)
//} else if (WebUI.getText(findTestObject('Object Repository/Page_Swag Labs/input_Checkout Your Information_last-name', null)).length() < 1) {
//    WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/h3_Error First Name is required'), 0)
//} else if (WebUI.getText(findTestObject('Object Repository/Page_Swag Labs/input_Checkout Your Information_postal-code', null)).length() < 1) {
//    WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/h3_Error First Name is required'), 0)
//} else {
//    WebUI.navigateToUrl('https://www.saucedemo.com/checkout-step-two.html')
//}
WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/div_QTYDESCRIPTION1Sauce Labs BackpackcarryallTheThings() with the sleek streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection2999'), 
    30)

WebUI.click(findTestObject('Object Repository/Page_Swag Labs/a_FINISH'))

WebUI.navigateToUrl('https://www.saucedemo.com/checkout-complete.html')

WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/h2_THANK YOU FOR YOUR ORDER'), 0)

WebUI.closeBrowser()

